# AutoService Manager

Полноценная система управления СТО: Blazor Server + PostgreSQL + ASP.NET Identity.

## Быстрый старт

**Требования:** .NET 8 SDK, PostgreSQL

```powershell
# 1. Создать БД и пользователя (один раз)
& "C:\Program Files\PostgreSQL\18\bin\psql.exe" -U postgres -c "CREATE USER autoservice WITH PASSWORD 'autoservice_pass' SUPERUSER;"
& "C:\Program Files\PostgreSQL\18\bin\psql.exe" -U postgres -c "CREATE DATABASE autoservice_db OWNER autoservice;"

# 2. Запустить
cd src\AutoServiceManager.Web
dotnet run
```

Открыть: **http://localhost:5000**

## Docker

```bash
docker compose up --build
```

Открыть: **http://localhost:8080**

## Демо-аккаунты (пароль: `Password123!`)

| Роль | Email |
|------|-------|
| Администратор | admin@sto.ru |
| Управляющий | manager@sto.ru |
| Мастер | mechanic1@sto.ru |
| Клиент | client@sto.ru |

## Страницы

| URL | Кто видит |
|-----|-----------|
| `/` | Все (публичная главная) |
| `/services` | Все (услуги и цены) |
| `/login`, `/register` | Гости |
| `/cabinet` | Клиент |
| `/cabinet/cars` | Клиент |
| `/cabinet/new` | Клиент |
| `/cabinet/request/{id}` | Клиент, Мастер |
| `/mechanic` | Мастер |
| `/manager` | Управляющий |
| `/manager/requests` | Управляющий |
| `/manager/request/{id}` | Управляющий |
| `/manager/parts` | Управляющий |
| `/manager/finance` | Управляющий |
| `/admin` | Администратор |
| `/admin/users` | Администратор |
| `/admin/service-types` | Администратор |
| `/admin/settings` | Администратор |
