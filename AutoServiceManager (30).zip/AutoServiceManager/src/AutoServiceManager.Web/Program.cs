using AutoServiceManager.Data;
using AutoServiceManager.Data.Context;
using AutoServiceManager.Data.Repositories;
using AutoServiceManager.Domain.Entities;
using AutoServiceManager.Services.Implementations;
using AutoServiceManager.Services.Interfaces;
using AutoServiceManager.Web.Components;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

// Fix for Npgsql DateTime UTC issue globally
AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

var builder = WebApplication.CreateBuilder(args);

var conn = builder.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("No 'Default' connection string.");

builder.Services.AddDbContext<AppDbContext>(o => o.UseNpgsql(conn));

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(o =>
{
    o.Password.RequireDigit = true; o.Password.RequiredLength = 8;
    o.Password.RequireNonAlphanumeric = false; o.Password.RequireUppercase = true;
    o.SignIn.RequireConfirmedEmail = false;
})
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(o =>
{
    o.LoginPath = "/login";
    o.AccessDeniedPath = "/";
    o.Cookie.SameSite = SameSiteMode.Lax;
    o.Cookie.SecurePolicy = CookieSecurePolicy.None;
    o.ExpireTimeSpan = TimeSpan.FromDays(14);
});

builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<IRequestService,  RequestService>();
builder.Services.AddScoped<IPartService,     PartService>();
builder.Services.AddScoped<IInvoiceService,  InvoiceService>();
builder.Services.AddScoped<IReviewService,   ReviewService>();
builder.Services.AddScoped<ISettingService,  SettingService>();

builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddControllersWithViews();

var app = builder.Build();
app.UseDeveloperExceptionPage();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapControllers();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var um = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
    var rm = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    await DbSeeder.SeedAsync(db, um, rm);
}

app.Run();
