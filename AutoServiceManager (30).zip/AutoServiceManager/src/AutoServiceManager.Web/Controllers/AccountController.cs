using AutoServiceManager.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AutoServiceManager.Web.Controllers;

[Route("auth")]
[IgnoreAntiforgeryToken]
public class AccountController(SignInManager<ApplicationUser> signIn, UserManager<ApplicationUser> users) : Controller
{
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromForm] string email, [FromForm] string password,
        [FromForm] bool remember, [FromForm] string? returnUrl)
    {
        var user = await users.FindByEmailAsync(email ?? "");
        if (user == null || user.IsBlocked) return Redirect("/login?err=1");
        if (!(await signIn.PasswordSignInAsync(email!, password, remember, false)).Succeeded) return Redirect("/login?err=1");
        if (!string.IsNullOrEmpty(returnUrl) && returnUrl.StartsWith("/")) return Redirect(returnUrl);
        var roles = await users.GetRolesAsync(user);
        if (roles.Contains("Admin"))    return Redirect("/admin");
        if (roles.Contains("Manager"))  return Redirect("/manager");
        if (roles.Contains("Mechanic")) return Redirect("/mechanic");
        return Redirect("/cabinet");
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromForm] string firstName, [FromForm] string lastName,
        [FromForm] string email, [FromForm] string phone, [FromForm] string password, [FromForm] string confirm)
    {
        if (password != confirm) return Redirect("/register?err=" + Uri.EscapeDataString("Пароли не совпадают"));
        if (await users.FindByEmailAsync(email ?? "") != null) return Redirect("/register?err=" + Uri.EscapeDataString("Email уже занят"));
        var user = new ApplicationUser { UserName = email, Email = email, FirstName = firstName ?? "", LastName = lastName ?? "", PhoneNumber = phone, EmailConfirmed = true };
        var result = await users.CreateAsync(user, password);
        if (!result.Succeeded) return Redirect("/register?err=" + Uri.EscapeDataString(string.Join(". ", result.Errors.Select(e => e.Description))));
        await users.AddToRoleAsync(user, "Client");
        await signIn.SignInAsync(user, isPersistent: false);
        return Redirect("/cabinet");
    }

    [HttpGet("logout")]
    public async Task<IActionResult> Logout() { await signIn.SignOutAsync(); return Redirect("/"); }
}
