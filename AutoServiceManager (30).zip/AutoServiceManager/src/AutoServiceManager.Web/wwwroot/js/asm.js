// Navbar scroll effect
window.addEventListener('scroll', () => {
    const nav = document.getElementById('mainNav');
    if (nav) nav.classList.toggle('scrolled', window.scrollY > 10);
}, { passive: true });

// User dropdown
function toggleDropdown() {
    const dd = document.getElementById('ddMenu');
    if (!dd) return;
    const isOpen = dd.style.display === 'block';
    dd.style.display = isOpen ? 'none' : 'block';
}

document.addEventListener('click', function(e) {
    const dd = document.getElementById('ddMenu');
    if (!dd) return;
    const wrap = e.target.closest('.nav-user-wrap') || e.target.closest('#ddMenu');
    if (!wrap) dd.style.display = 'none';
}, true);

// Fill demo credentials
function fillDemo(email) {
    const ei = document.getElementById('emailInp');
    const pi = document.getElementById('pwdInp');
    if (ei) { ei.value = email; ei.dispatchEvent(new Event('input')); }
    if (pi) { pi.value = 'Password123!'; }
}

// Smooth scroll for anchors
document.addEventListener('click', function(e) {
    const a = e.target.closest('a[href^="/#"]');
    if (!a) return;
    const id = a.getAttribute('href').slice(2);
    const el = document.getElementById(id);
    if (el) { e.preventDefault(); el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
});
