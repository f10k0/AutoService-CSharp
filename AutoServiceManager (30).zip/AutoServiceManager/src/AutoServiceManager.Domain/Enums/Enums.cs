namespace AutoServiceManager.Domain.Enums;

public enum ServiceRequestStatus
{
    New = 0, Confirmed = 1, Diagnostics = 2, WaitingParts = 3,
    InProgress = 4, ReadyForPickup = 5, Completed = 6, Cancelled = 7
}

public enum UserRole { Client, Mechanic, Manager, Admin }
public enum PaymentStatus { Unpaid, PartiallyPaid, Paid }
public enum PartMovementType { Incoming, Outgoing }
