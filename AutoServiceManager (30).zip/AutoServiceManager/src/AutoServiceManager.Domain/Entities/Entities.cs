using AutoServiceManager.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace AutoServiceManager.Domain.Entities;

public class ApplicationUser : IdentityUser
{
    public string FirstName  { get; set; } = "";
    public string LastName   { get; set; } = "";
    public string? Patronymic { get; set; }
    public string? Address    { get; set; }
    public bool IsBlocked     { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<Car>                Cars               { get; set; } = [];
    public ICollection<ServiceRequest>     ServiceRequests    { get; set; } = [];
    public ICollection<MechanicAssignment> MechanicAssignments{ get; set; } = [];
    public ICollection<Review>             Reviews            { get; set; } = [];

    [NotMapped] public string FullName => $"{LastName} {FirstName} {Patronymic}".Trim();
    [NotMapped] public string DisplayName => !string.IsNullOrWhiteSpace(FirstName) ? $"{FirstName} {LastName}".Trim() : Email ?? "";
}

public class Car
{
    public int     Id           { get; set; }
    public string  OwnerId      { get; set; } = "";
    public ApplicationUser Owner{ get; set; } = null!;
    public string  LicensePlate { get; set; } = "";
    public string  Brand        { get; set; } = "";
    public string  Model        { get; set; } = "";
    public int     Year         { get; set; }
    public string? Vin          { get; set; }
    public string? Color        { get; set; }
    public bool    IsDeleted    { get; set; }
    public ICollection<ServiceRequest> ServiceRequests { get; set; } = [];
    [NotMapped] public string DisplayName => $"{Brand} {Model} ({Year}) · {LicensePlate}";
}

public class ServiceType
{
    public int     Id             { get; set; }
    public string  Name           { get; set; } = "";
    public string? Description    { get; set; }
    public decimal BasePrice      { get; set; }
    public decimal EstimatedHours { get; set; }
    public bool    IsActive       { get; set; } = true;
    public ICollection<ServiceRequest> ServiceRequests { get; set; } = [];
}

public class Lift
{
    public int     Id          { get; set; }
    public string  Name        { get; set; } = "";
    public string? Description { get; set; }
    public bool    IsActive    { get; set; } = true;
    public ICollection<MechanicAssignment> Assignments { get; set; } = [];
}

public class ServiceRequest
{
    public int     Id                 { get; set; }
    public string  ClientId           { get; set; } = "";
    public ApplicationUser Client     { get; set; } = null!;
    public int     CarId              { get; set; }
    public Car     Car                { get; set; } = null!;
    public int?    ServiceTypeId      { get; set; }
    public ServiceType? ServiceType   { get; set; }
    public ServiceRequestStatus Status{ get; set; } = ServiceRequestStatus.New;
    public string  Description        { get; set; } = "";
    public string? DiagnosticResult   { get; set; }
    public string? ManagerComment     { get; set; }
    public string? CancellationReason { get; set; }
    public DateTime  CreatedAt        { get; set; } = DateTime.UtcNow;
    public DateTime? DesiredDate      { get; set; }
    public DateTime? StartedAt        { get; set; }
    public DateTime? CompletedAt      { get; set; }
    public int Priority               { get; set; }
    public ICollection<MechanicAssignment> MechanicAssignments { get; set; } = [];
    public ICollection<UsedPart>           UsedParts           { get; set; } = [];
    public ICollection<StatusHistory>      StatusHistory       { get; set; } = [];
    public Invoice? Invoice { get; set; }
    public Review?  Review  { get; set; }

    [NotMapped] public string StatusLabel => Status switch
    {
        ServiceRequestStatus.New            => "Новая",
        ServiceRequestStatus.Confirmed      => "Подтверждена",
        ServiceRequestStatus.Diagnostics    => "Диагностика",
        ServiceRequestStatus.WaitingParts   => "Ожидание запчастей",
        ServiceRequestStatus.InProgress     => "В работе",
        ServiceRequestStatus.ReadyForPickup => "Готово к выдаче",
        ServiceRequestStatus.Completed      => "Выполнена",
        ServiceRequestStatus.Cancelled      => "Отменена",
        _ => "?"
    };

    [NotMapped] public string StatusCss => Status switch
    {
        ServiceRequestStatus.New            => "badge-new",
        ServiceRequestStatus.Confirmed      => "badge-confirmed",
        ServiceRequestStatus.Diagnostics    => "badge-diagnostics",
        ServiceRequestStatus.WaitingParts   => "badge-waiting",
        ServiceRequestStatus.InProgress     => "badge-inprogress",
        ServiceRequestStatus.ReadyForPickup => "badge-ready",
        ServiceRequestStatus.Completed      => "badge-completed",
        ServiceRequestStatus.Cancelled      => "badge-cancelled",
        _ => ""
    };

    [NotMapped] public bool CanClientCancel => Status == ServiceRequestStatus.New;
    [NotMapped] public bool IsActive => Status is ServiceRequestStatus.Confirmed or
        ServiceRequestStatus.Diagnostics or ServiceRequestStatus.WaitingParts or
        ServiceRequestStatus.InProgress;
}

public class MechanicAssignment
{
    public int     Id               { get; set; }
    public int     ServiceRequestId { get; set; }
    public ServiceRequest ServiceRequest{ get; set; } = null!;
    public string  MechanicId       { get; set; } = "";
    public ApplicationUser Mechanic { get; set; } = null!;
    public int?    LiftId           { get; set; }
    public Lift?   Lift             { get; set; }
    public DateTime? ScheduledStart { get; set; }
    public DateTime? ScheduledEnd   { get; set; }
    public string? WorkNotes        { get; set; }
}

public class Part
{
    public int     Id               { get; set; }
    public string  Name             { get; set; } = "";
    public string  ArticleNumber    { get; set; } = "";
    public string? Description      { get; set; }
    public string? CompatibleBrands { get; set; }
    public string? CategoryName     { get; set; }
    public decimal PurchasePrice    { get; set; }
    public decimal SalePrice        { get; set; }
    public int     StockQuantity    { get; set; }
    public int     MinStockQuantity { get; set; }
    public bool    IsActive         { get; set; } = true;
    public ICollection<UsedPart>     UsedParts { get; set; } = [];
    public ICollection<PartMovement> Movements { get; set; } = [];
    [NotMapped] public bool IsLowStock => StockQuantity <= MinStockQuantity;
}

public class UsedPart
{
    public int     Id               { get; set; }
    public int     ServiceRequestId { get; set; }
    public ServiceRequest ServiceRequest{ get; set; } = null!;
    public int     PartId           { get; set; }
    public Part    Part             { get; set; } = null!;
    public int     Quantity         { get; set; }
    public decimal PriceAtTime      { get; set; }
    [NotMapped] public decimal Total => Quantity * PriceAtTime;
}

public class PartMovement
{
    public int     Id           { get; set; }
    public int     PartId       { get; set; }
    public Part    Part         { get; set; } = null!;
    public PartMovementType MovementType{ get; set; }
    public int     Quantity     { get; set; }
    public string? Comment      { get; set; }
    public string? UserId       { get; set; }
    public DateTime CreatedAt   { get; set; } = DateTime.UtcNow;
}

public class Invoice
{
    public int     Id               { get; set; }
    public int     ServiceRequestId { get; set; }
    public ServiceRequest ServiceRequest{ get; set; } = null!;
    public decimal LaborCost        { get; set; }
    public decimal PartsCost        { get; set; }
    public decimal Discount         { get; set; }
    [NotMapped] public decimal Total => LaborCost + PartsCost - Discount;
    public PaymentStatus PaymentStatus{ get; set; } = PaymentStatus.Unpaid;
    public decimal PaidAmount       { get; set; }
    public DateTime  CreatedAt      { get; set; } = DateTime.UtcNow;
    public DateTime? PaidAt         { get; set; }
    public string?   Notes          { get; set; }
    [NotMapped] public string PaymentLabel => PaymentStatus switch
    {
        PaymentStatus.Paid => "Оплачен",
        PaymentStatus.PartiallyPaid => $"Частично ({PaidAmount:N0} ₽)",
        _ => "Не оплачен"
    };
}

public class Review
{
    public int     Id               { get; set; }
    public int     ServiceRequestId { get; set; }
    public ServiceRequest ServiceRequest{ get; set; } = null!;
    public string  ClientId         { get; set; } = "";
    public ApplicationUser Client   { get; set; } = null!;
    public int     Rating           { get; set; }
    public string? Comment          { get; set; }
    public DateTime CreatedAt       { get; set; } = DateTime.UtcNow;
}

public class StatusHistory
{
    public int     Id               { get; set; }
    public int     ServiceRequestId { get; set; }
    public ServiceRequest ServiceRequest{ get; set; } = null!;
    public ServiceRequestStatus OldStatus{ get; set; }
    public ServiceRequestStatus NewStatus{ get; set; }
    public string? Comment          { get; set; }
    public string? ChangedByUserId  { get; set; }
    public DateTime ChangedAt       { get; set; } = DateTime.UtcNow;
}

public class SystemSetting
{
    public int     Id          { get; set; }
    public string  Key         { get; set; } = "";
    public string  Value       { get; set; } = "";
    public string? Description { get; set; }
}
