using AutoServiceManager.Domain.Entities;
using AutoServiceManager.Domain.Enums;

namespace AutoServiceManager.Services.Interfaces;

public interface IRequestService
{
    Task<ServiceRequest?> GetByIdAsync(int id);
    Task<IReadOnlyList<ServiceRequest>> GetAllAsync();
    Task<IReadOnlyList<ServiceRequest>> GetByClientAsync(string clientId);
    Task<IReadOnlyList<ServiceRequest>> GetByMechanicAsync(string mechanicId);
    Task<ServiceRequest> CreateAsync(ServiceRequest r);
    Task ChangeStatusAsync(int id, ServiceRequestStatus status, string? comment, string? byUserId);
    Task AssignAsync(int requestId, string mechanicId, int? liftId, DateTime? start, DateTime? end);
    Task<int> CountActiveAsync();
    Task<decimal> MonthRevenueAsync();
    Task<IReadOnlyList<ServiceRequest>> GetRecentAsync(int count = 10);
}

public interface IPartService
{
    Task<IReadOnlyList<Part>> GetAllAsync();
    Task<Part?> GetByIdAsync(int id);
    Task<Part> CreateAsync(Part p);
    Task UpdateAsync(Part p);
    Task<IReadOnlyList<Part>> GetLowStockAsync();
    Task AddStockAsync(int partId, int qty, string? comment, string? userId);
    Task<bool> UsePartAsync(int requestId, int partId, int qty, string? userId);
}

public interface IInvoiceService
{
    Task<Invoice?> GetByRequestAsync(int requestId);
    Task<Invoice> GenerateAsync(int requestId);
    Task UpdateAsync(Invoice inv);
    Task MarkPaidAsync(int invoiceId, decimal amount);
}

public interface IReviewService
{
    Task<IReadOnlyList<Review>> GetAllAsync();
    Task<Review?> GetByRequestAsync(int requestId);
    Task<Review> CreateAsync(int requestId, string clientId, int rating, string? comment);
    Task<double> AvgRatingAsync();
}

public interface ISettingService
{
    Task<string> GetAsync(string key, string defaultVal = "");
    Task SetAsync(string key, string value);
    Task<decimal> HourlyRateAsync();
    Task<IReadOnlyList<SystemSetting>> GetAllAsync();
}
