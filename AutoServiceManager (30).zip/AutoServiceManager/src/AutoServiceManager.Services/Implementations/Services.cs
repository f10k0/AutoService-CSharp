using AutoServiceManager.Data.Context;
using AutoServiceManager.Domain.Entities;
using AutoServiceManager.Domain.Enums;
using AutoServiceManager.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace AutoServiceManager.Services.Implementations;

public class RequestService(AppDbContext db) : IRequestService
{
    private IQueryable<ServiceRequest> Base() => db.ServiceRequests
        .Include(r => r.Client).Include(r => r.Car)
        .Include(r => r.ServiceType)
        .Include(r => r.MechanicAssignments).ThenInclude(a => a.Mechanic)
        .Include(r => r.MechanicAssignments).ThenInclude(a => a.Lift);

    public async Task<ServiceRequest?> GetByIdAsync(int id) =>
        await Base()
            .Include(r => r.UsedParts).ThenInclude(u => u.Part)
            .Include(r => r.StatusHistory)
            .Include(r => r.Invoice)
            .Include(r => r.Review)
            .FirstOrDefaultAsync(r => r.Id == id);

    public async Task<IReadOnlyList<ServiceRequest>> GetAllAsync() =>
        await Base().OrderByDescending(r => r.CreatedAt).ToListAsync();

    public async Task<IReadOnlyList<ServiceRequest>> GetByClientAsync(string clientId) =>
        await Base()
            .Include(r => r.Invoice)
            .Where(r => r.ClientId == clientId)
            .OrderByDescending(r => r.CreatedAt).ToListAsync();

    public async Task<IReadOnlyList<ServiceRequest>> GetByMechanicAsync(string mechanicId) =>
        await Base()
            .Where(r => r.MechanicAssignments.Any(a => a.MechanicId == mechanicId))
            .OrderByDescending(r => r.CreatedAt).ToListAsync();

    public async Task<ServiceRequest> CreateAsync(ServiceRequest r)
    {
        r.CreatedAt = DateTime.UtcNow;
        r.Status = ServiceRequestStatus.New;
        db.ServiceRequests.Add(r);
        db.StatusHistories.Add(new StatusHistory
        {
            ServiceRequest = r, OldStatus = ServiceRequestStatus.New,
            NewStatus = ServiceRequestStatus.New, Comment = "Заявка создана",
            ChangedByUserId = r.ClientId, ChangedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
        return r;
    }

    public async Task ChangeStatusAsync(int id, ServiceRequestStatus status, string? comment, string? byUserId)
    {
        using var tx = await db.Database.BeginTransactionAsync();
        var r = await db.ServiceRequests.FindAsync(id) ?? throw new Exception("Not found");
        var old = r.Status;
        r.Status = status;
        if (status == ServiceRequestStatus.InProgress && r.StartedAt == null) r.StartedAt = DateTime.UtcNow;
        if (status is ServiceRequestStatus.Completed or ServiceRequestStatus.ReadyForPickup) r.CompletedAt = DateTime.UtcNow;
        db.StatusHistories.Add(new StatusHistory
        {
            ServiceRequestId = id, OldStatus = old, NewStatus = status,
            Comment = comment, ChangedByUserId = byUserId, ChangedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
        await tx.CommitAsync();
    }

    public async Task AssignAsync(int requestId, string mechanicId, int? liftId, DateTime? start, DateTime? end)
    {
        var ex = await db.MechanicAssignments.FirstOrDefaultAsync(a => a.ServiceRequestId == requestId);
        if (ex != null) { ex.MechanicId = mechanicId; ex.LiftId = liftId; ex.ScheduledStart = start; ex.ScheduledEnd = end; }
        else db.MechanicAssignments.Add(new MechanicAssignment { ServiceRequestId = requestId, MechanicId = mechanicId, LiftId = liftId, ScheduledStart = start, ScheduledEnd = end });
        await db.SaveChangesAsync();
    }

    public async Task<int> CountActiveAsync() =>
        await db.ServiceRequests.CountAsync(r => r.Status == ServiceRequestStatus.Confirmed ||
            r.Status == ServiceRequestStatus.Diagnostics || r.Status == ServiceRequestStatus.WaitingParts ||
            r.Status == ServiceRequestStatus.InProgress);

    public async Task<decimal> MonthRevenueAsync()
    {
        var now = DateTime.UtcNow;
        var start = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        return await db.Invoices.Where(i => i.CreatedAt >= start && i.PaymentStatus != PaymentStatus.Unpaid).SumAsync(i => i.PaidAmount);
    }

    public async Task<IReadOnlyList<ServiceRequest>> GetRecentAsync(int count = 10) =>
        await Base().OrderByDescending(r => r.CreatedAt).Take(count).ToListAsync();
}

public class PartService(AppDbContext db) : IPartService
{
    public async Task<IReadOnlyList<Part>> GetAllAsync() =>
        await db.Parts.Where(p => p.IsActive).OrderBy(p => p.CategoryName).ThenBy(p => p.Name).ToListAsync();

    public async Task<Part?> GetByIdAsync(int id) => await db.Parts.FindAsync(id);

    public async Task<Part> CreateAsync(Part p) { db.Parts.Add(p); await db.SaveChangesAsync(); return p; }

    public async Task UpdateAsync(Part p)
    {
        var ex = await db.Parts.FindAsync(p.Id);
        if (ex == null) return;
        ex.Name = p.Name; ex.ArticleNumber = p.ArticleNumber; ex.CategoryName = p.CategoryName;
        ex.PurchasePrice = p.PurchasePrice; ex.SalePrice = p.SalePrice;
        ex.MinStockQuantity = p.MinStockQuantity; ex.Description = p.Description;
        ex.CompatibleBrands = p.CompatibleBrands; ex.IsActive = p.IsActive;
        await db.SaveChangesAsync();
    }

    public async Task<IReadOnlyList<Part>> GetLowStockAsync() =>
        await db.Parts.Where(p => p.IsActive && p.StockQuantity <= p.MinStockQuantity).ToListAsync();

    public async Task AddStockAsync(int partId, int qty, string? comment, string? userId)
    {
        using var tx = await db.Database.BeginTransactionAsync();
        var p = await db.Parts.FindAsync(partId) ?? throw new Exception("Not found");
        p.StockQuantity += qty;
        db.PartMovements.Add(new PartMovement { PartId = partId, MovementType = PartMovementType.Incoming, Quantity = qty, Comment = comment ?? "Поступление", UserId = userId });
        await db.SaveChangesAsync();
        await tx.CommitAsync();
    }

    public async Task<bool> UsePartAsync(int requestId, int partId, int qty, string? userId)
    {
        using var tx = await db.Database.BeginTransactionAsync();
        var p = await db.Parts.FindAsync(partId);
        if (p == null || p.StockQuantity < qty) return false;
        p.StockQuantity -= qty;
        var ex = await db.UsedParts.FirstOrDefaultAsync(u => u.ServiceRequestId == requestId && u.PartId == partId);
        if (ex != null) ex.Quantity += qty;
        else db.UsedParts.Add(new UsedPart { ServiceRequestId = requestId, PartId = partId, Quantity = qty, PriceAtTime = p.SalePrice });
        db.PartMovements.Add(new PartMovement { PartId = partId, MovementType = PartMovementType.Outgoing, Quantity = qty, Comment = $"Заявка #{requestId}", UserId = userId });
        await db.SaveChangesAsync();
        await tx.CommitAsync();
        return true;
    }
}

public class InvoiceService(AppDbContext db) : IInvoiceService
{
    public async Task<Invoice?> GetByRequestAsync(int requestId) =>
        await db.Invoices.Include(i => i.ServiceRequest).ThenInclude(r => r.Client)
            .Include(i => i.ServiceRequest).ThenInclude(r => r.Car)
            .Include(i => i.ServiceRequest).ThenInclude(r => r.UsedParts).ThenInclude(u => u.Part)
            .FirstOrDefaultAsync(i => i.ServiceRequestId == requestId);

    public async Task<Invoice> GenerateAsync(int requestId)
    {
        var r = await db.ServiceRequests.Include(r => r.ServiceType).Include(r => r.UsedParts)
            .FirstOrDefaultAsync(r => r.Id == requestId) ?? throw new Exception("Not found");

        var rate = await db.SystemSettings.FirstOrDefaultAsync(s => s.Key == "HourlyRate");
        decimal hourly = decimal.TryParse(rate?.Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var h) ? h : 1500;
        decimal labor = (r.ServiceType?.EstimatedHours ?? 1) * hourly;
        decimal parts = r.UsedParts.Sum(u => u.Quantity * u.PriceAtTime);

        var inv = await db.Invoices.FirstOrDefaultAsync(i => i.ServiceRequestId == requestId);
        if (inv != null) { inv.LaborCost = labor; inv.PartsCost = parts; }
        else { inv = new Invoice { ServiceRequestId = requestId, LaborCost = labor, PartsCost = parts }; db.Invoices.Add(inv); }
        await db.SaveChangesAsync();
        return inv;
    }

    public async Task UpdateAsync(Invoice inv)
    {
        var ex = await db.Invoices.FindAsync(inv.Id);
        if (ex == null) return;
        ex.LaborCost = inv.LaborCost; ex.PartsCost = inv.PartsCost; ex.Discount = inv.Discount; ex.Notes = inv.Notes;
        await db.SaveChangesAsync();
    }

    public async Task MarkPaidAsync(int invoiceId, decimal amount)
    {
        var inv = await db.Invoices.FindAsync(invoiceId) ?? throw new Exception("Not found");
        inv.PaidAmount += amount;
        inv.PaymentStatus = inv.PaidAmount >= inv.LaborCost + inv.PartsCost - inv.Discount ? PaymentStatus.Paid : PaymentStatus.PartiallyPaid;
        if (inv.PaymentStatus == PaymentStatus.Paid) inv.PaidAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
    }
}

public class ReviewService(AppDbContext db) : IReviewService
{
    public async Task<IReadOnlyList<Review>> GetAllAsync() =>
        await db.Reviews.Include(r => r.Client).Include(r => r.ServiceRequest).ThenInclude(s => s.Car)
            .OrderByDescending(r => r.CreatedAt).ToListAsync();

    public async Task<Review?> GetByRequestAsync(int requestId) =>
        await db.Reviews.FirstOrDefaultAsync(r => r.ServiceRequestId == requestId);

    public async Task<Review> CreateAsync(int requestId, string clientId, int rating, string? comment)
    {
        var rev = new Review { ServiceRequestId = requestId, ClientId = clientId, Rating = rating, Comment = comment };
        db.Reviews.Add(rev); await db.SaveChangesAsync(); return rev;
    }

    public async Task<double> AvgRatingAsync() =>
        await db.Reviews.AnyAsync() ? await db.Reviews.AverageAsync(r => (double)r.Rating) : 0;
}

public class SettingService(AppDbContext db) : ISettingService
{
    public async Task<string> GetAsync(string key, string defaultVal = "") =>
        (await db.SystemSettings.FirstOrDefaultAsync(s => s.Key == key))?.Value ?? defaultVal;

    public async Task SetAsync(string key, string value)
    {
        var s = await db.SystemSettings.FirstOrDefaultAsync(x => x.Key == key);
        if (s != null) s.Value = value;
        else db.SystemSettings.Add(new SystemSetting { Key = key, Value = value });
        await db.SaveChangesAsync();
    }

    public async Task<decimal> HourlyRateAsync() =>
        decimal.TryParse(await GetAsync("HourlyRate", "1500"), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var r) ? r : 1500;

    public async Task<IReadOnlyList<SystemSetting>> GetAllAsync() =>
        await db.SystemSettings.OrderBy(s => s.Key).ToListAsync();
}
