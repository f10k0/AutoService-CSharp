using System.Linq.Expressions;
using AutoServiceManager.Data.Context;
using Microsoft.EntityFrameworkCore;

namespace AutoServiceManager.Data.Repositories;

public interface IRepository<T> where T : class
{
    Task<T?> GetByIdAsync(int id);
    Task<IReadOnlyList<T>> GetAllAsync();
    Task<T> AddAsync(T entity);
    Task UpdateAsync(T entity);
    Task DeleteAsync(T entity);
    IQueryable<T> Query();
}

public class Repository<T>(AppDbContext db) : IRepository<T> where T : class
{
    private readonly DbSet<T> _set = db.Set<T>();
    public async Task<T?> GetByIdAsync(int id) => await _set.FindAsync(id);
    public async Task<IReadOnlyList<T>> GetAllAsync() => await _set.ToListAsync();
    public async Task<T> AddAsync(T entity) { await _set.AddAsync(entity); await db.SaveChangesAsync(); return entity; }
    public async Task UpdateAsync(T entity) { _set.Update(entity); await db.SaveChangesAsync(); }
    public async Task DeleteAsync(T entity) { _set.Remove(entity); await db.SaveChangesAsync(); }
    public IQueryable<T> Query() => _set.AsQueryable();
}
