using AutoServiceManager.Domain.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AutoServiceManager.Data.Context;

public class AppDbContext(DbContextOptions<AppDbContext> options) : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<Car>               Cars               => Set<Car>();
    public DbSet<ServiceType>       ServiceTypes       => Set<ServiceType>();
    public DbSet<Lift>              Lifts              => Set<Lift>();
    public DbSet<ServiceRequest>    ServiceRequests    => Set<ServiceRequest>();
    public DbSet<MechanicAssignment>MechanicAssignments=> Set<MechanicAssignment>();
    public DbSet<Part>              Parts              => Set<Part>();
    public DbSet<UsedPart>          UsedParts          => Set<UsedPart>();
    public DbSet<PartMovement>      PartMovements      => Set<PartMovement>();
    public DbSet<Invoice>           Invoices           => Set<Invoice>();
    public DbSet<Review>            Reviews            => Set<Review>();
    public DbSet<StatusHistory>     StatusHistories    => Set<StatusHistory>();
    public DbSet<SystemSetting>     SystemSettings     => Set<SystemSetting>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        b.Entity<Car>(e =>
        {
            e.HasOne(c => c.Owner).WithMany(u => u.Cars).HasForeignKey(c => c.OwnerId).OnDelete(DeleteBehavior.Restrict);
            e.HasQueryFilter(c => !c.IsDeleted);
        });

        b.Entity<ServiceRequest>(e =>
        {
            e.HasOne(r => r.Client).WithMany(u => u.ServiceRequests).HasForeignKey(r => r.ClientId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(r => r.Car).WithMany(c => c.ServiceRequests).HasForeignKey(r => r.CarId).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<MechanicAssignment>(e =>
        {
            e.HasOne(a => a.ServiceRequest).WithMany(r => r.MechanicAssignments).HasForeignKey(a => a.ServiceRequestId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(a => a.Mechanic).WithMany(u => u.MechanicAssignments).HasForeignKey(a => a.MechanicId).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<UsedPart>(e =>
        {
            e.HasOne(u => u.ServiceRequest).WithMany(r => r.UsedParts).HasForeignKey(u => u.ServiceRequestId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(u => u.Part).WithMany(p => p.UsedParts).HasForeignKey(u => u.PartId).OnDelete(DeleteBehavior.Restrict);
            e.Property(u => u.PriceAtTime).HasColumnType("numeric(18,2)");
            e.Ignore(u => u.Total);
        });

        b.Entity<Invoice>(e =>
        {
            e.HasOne(i => i.ServiceRequest).WithOne(r => r.Invoice).HasForeignKey<Invoice>(i => i.ServiceRequestId).OnDelete(DeleteBehavior.Cascade);
            e.Property(i => i.LaborCost).HasColumnType("numeric(18,2)");
            e.Property(i => i.PartsCost).HasColumnType("numeric(18,2)");
            e.Property(i => i.Discount).HasColumnType("numeric(18,2)");
            e.Property(i => i.PaidAmount).HasColumnType("numeric(18,2)");
            e.Ignore(i => i.Total);
            e.Ignore(i => i.PaymentLabel);
        });

        b.Entity<Review>(e =>
        {
            e.HasOne(r => r.ServiceRequest).WithOne(s => s.Review).HasForeignKey<Review>(r => r.ServiceRequestId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(r => r.Client).WithMany(u => u.Reviews).HasForeignKey(r => r.ClientId).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<Part>(e =>
        {
            e.Property(p => p.PurchasePrice).HasColumnType("numeric(18,2)");
            e.Property(p => p.SalePrice).HasColumnType("numeric(18,2)");
            e.Ignore(p => p.IsLowStock);
        });

        b.Entity<ServiceType>(e =>
        {
            e.Property(s => s.BasePrice).HasColumnType("numeric(18,2)");
            e.Property(s => s.EstimatedHours).HasColumnType("numeric(5,2)");
        });

        b.Entity<SystemSetting>().HasIndex(s => s.Key).IsUnique();

        // Ignore NotMapped computed props from ServiceRequest/Car/ApplicationUser
        b.Entity<ServiceRequest>().Ignore(r => r.StatusLabel).Ignore(r => r.StatusCss).Ignore(r => r.CanClientCancel).Ignore(r => r.IsActive);
        b.Entity<Car>().Ignore(c => c.DisplayName);
        b.Entity<ApplicationUser>().Ignore(u => u.FullName).Ignore(u => u.DisplayName);
    }
}
