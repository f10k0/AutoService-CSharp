using AutoServiceManager.Data.Context;
using AutoServiceManager.Domain.Entities;
using AutoServiceManager.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace AutoServiceManager.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(AppDbContext db, UserManager<ApplicationUser> um, RoleManager<IdentityRole> rm)
    {
        // 1. Schema via raw SQL
        var conn = db.Database.GetDbConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = SchemaSql;
        await cmd.ExecuteNonQueryAsync();
        await conn.CloseAsync();

        // 2. Roles
        foreach (var role in new[] { "Admin", "Manager", "Mechanic", "Client" })
            if (!await db.Roles.AnyAsync(r => r.Name == role))
                await rm.CreateAsync(new IdentityRole(role));

        // 3. Users
        await EnsureUser(um, "admin@sto.ru",     "Password123!", "Admin",    "Алексей", "Администраторов", "+7-900-000-0001");
        await EnsureUser(um, "manager@sto.ru",   "Password123!", "Manager",  "Мария",   "Управляющая",     "+7-900-000-0002");
        await EnsureUser(um, "mechanic1@sto.ru", "Password123!", "Mechanic", "Иван",    "Кузнецов",        "+7-900-000-0003");
        await EnsureUser(um, "mechanic2@sto.ru", "Password123!", "Mechanic", "Пётр",    "Сварщиков",       "+7-900-000-0004");
        await EnsureUser(um, "client@sto.ru",    "Password123!", "Client",   "Андрей",  "Клиентов",        "+7-900-000-0005");

        // 4. Reference data
        if (await db.ServiceTypes.AnyAsync()) return;

        db.ServiceTypes.AddRange(
            new ServiceType { Name="Диагностика двигателя",   Description="Компьютерная диагностика",            BasePrice=1500,  EstimatedHours=1m   },
            new ServiceType { Name="Замена масла и фильтров",  Description="ТО — масло, фильтры",                BasePrice=2000,  EstimatedHours=0.5m },
            new ServiceType { Name="Ремонт тормозной системы", Description="Колодки, диски, прокачка",           BasePrice=4000,  EstimatedHours=2m   },
            new ServiceType { Name="Замена ремня ГРМ",         Description="Ремень/цепь ГРМ с роликами",         BasePrice=8000,  EstimatedHours=4m   },
            new ServiceType { Name="Развал-схождение",         Description="Регулировка углов установки колёс",  BasePrice=2500,  EstimatedHours=1m   },
            new ServiceType { Name="Ремонт подвески",          Description="Амортизаторы, сайлентблоки, рычаги", BasePrice=5000,  EstimatedHours=3m   },
            new ServiceType { Name="Кузовной ремонт",          Description="Рихтовка, покраска",                 BasePrice=10000, EstimatedHours=8m   },
            new ServiceType { Name="Замена сцепления",         Description="Сцепление в сборе",                  BasePrice=7000,  EstimatedHours=5m   }
        );
        db.Lifts.AddRange(
            new Lift { Name="Пост №1", Description="Двухстоечный 4т" },
            new Lift { Name="Пост №2", Description="Двухстоечный 4т" },
            new Lift { Name="Пост №3", Description="Четырёхстоечный 5т" },
            new Lift { Name="Пост №4", Description="Смотровая яма" }
        );
        db.Parts.AddRange(
            new Part { Name="Масло 5W-40 (4л)",         ArticleNumber="OIL-5W40",    CategoryName="Масла",       PurchasePrice=900,  SalePrice=1300, StockQuantity=50, MinStockQuantity=10 },
            new Part { Name="Фильтр масляный",           ArticleNumber="FILTER-OIL",  CategoryName="Фильтры",     PurchasePrice=200,  SalePrice=380,  StockQuantity=30, MinStockQuantity=5  },
            new Part { Name="Тормозные колодки передние",ArticleNumber="BRAKE-PAD-F", CategoryName="Тормоза",     PurchasePrice=1200, SalePrice=2100, StockQuantity=20, MinStockQuantity=4  },
            new Part { Name="Тормозные колодки задние",  ArticleNumber="BRAKE-PAD-R", CategoryName="Тормоза",     PurchasePrice=900,  SalePrice=1600, StockQuantity=15, MinStockQuantity=4  },
            new Part { Name="Свечи зажигания (4 шт)",   ArticleNumber="SPARK-NGK",   CategoryName="Электрика",   PurchasePrice=800,  SalePrice=1400, StockQuantity=25, MinStockQuantity=5  },
            new Part { Name="Антифриз G12 (1л)",         ArticleNumber="COOLANT-G12", CategoryName="Жидкости",    PurchasePrice=150,  SalePrice=280,  StockQuantity=40, MinStockQuantity=8  },
            new Part { Name="Ремень ГРМ Gates",          ArticleNumber="BELT-GATES",  CategoryName="ГРМ",         PurchasePrice=2500, SalePrice=4200, StockQuantity=8,  MinStockQuantity=2  },
            new Part { Name="Амортизатор передний",      ArticleNumber="SHOCK-F",     CategoryName="Подвеска",    PurchasePrice=3200, SalePrice=5500, StockQuantity=3,  MinStockQuantity=2  }
        );
        db.SystemSettings.AddRange(
            new SystemSetting { Key="HourlyRate",     Value="1500",             Description="Нормо-час, руб." },
            new SystemSetting { Key="CompanyName",    Value="АвтоСервис Профи", Description="Название" },
            new SystemSetting { Key="CompanyPhone",   Value="+7 (800) 123-45-67" },
            new SystemSetting { Key="CompanyAddress", Value="г. Москва, ул. Автомобильная, 15" },
            new SystemSetting { Key="WorkStart",      Value="09:00" },
            new SystemSetting { Key="WorkEnd",        Value="20:00" }
        );

        // Demo client car + request
        var clientUser = await um.FindByEmailAsync("client@sto.ru");
        if (clientUser != null && !await db.Cars.AnyAsync())
        {
            var car = new Car { OwnerId=clientUser.Id, Brand="Toyota", Model="Camry", Year=2020, LicensePlate="А777БВ 77", Color="Белый" };
            db.Cars.Add(car);
            await db.SaveChangesAsync();

            var req = new ServiceRequest
            {
                ClientId=clientUser.Id, CarId=car.Id, ServiceTypeId=1,
                Status=ServiceRequestStatus.InProgress,
                Description="Стук в передней подвеске, вибрация на скорости 80+ км/ч",
                CreatedAt=DateTime.UtcNow.AddDays(-2), StartedAt=DateTime.UtcNow.AddDays(-1)
            };
            db.ServiceRequests.Add(req);
            await db.SaveChangesAsync();

            db.StatusHistories.Add(new StatusHistory { ServiceRequestId=req.Id, OldStatus=ServiceRequestStatus.New, NewStatus=ServiceRequestStatus.New, Comment="Заявка создана", ChangedAt=DateTime.UtcNow.AddDays(-2) });
            db.StatusHistories.Add(new StatusHistory { ServiceRequestId=req.Id, OldStatus=ServiceRequestStatus.New, NewStatus=ServiceRequestStatus.InProgress, Comment="Мастер приступил", ChangedAt=DateTime.UtcNow.AddDays(-1) });
        }

        await db.SaveChangesAsync();
    }

    private static async Task EnsureUser(UserManager<ApplicationUser> um, string email, string password, string role, string first, string last, string phone)
    {
        if (await um.FindByEmailAsync(email) != null) return;
        var user = new ApplicationUser { UserName=email, Email=email, FirstName=first, LastName=last, PhoneNumber=phone, EmailConfirmed=true };
        var r = await um.CreateAsync(user, password);
        if (r.Succeeded) await um.AddToRoleAsync(user, role);
    }

    private const string SchemaSql = """
        CREATE TABLE IF NOT EXISTS "AspNetRoles"("Id" text NOT NULL PRIMARY KEY,"Name" character varying(256),"NormalizedName" character varying(256),"ConcurrencyStamp" text);
        CREATE UNIQUE INDEX IF NOT EXISTS "RoleNameIndex" ON "AspNetRoles"("NormalizedName") WHERE "NormalizedName" IS NOT NULL;
        CREATE TABLE IF NOT EXISTS "AspNetUsers"("Id" text NOT NULL PRIMARY KEY,"FirstName" text NOT NULL DEFAULT '',"LastName" text NOT NULL DEFAULT '',"Patronymic" text,"Address" text,"IsBlocked" boolean NOT NULL DEFAULT false,"CreatedAt" timestamptz NOT NULL DEFAULT now(),"UserName" character varying(256),"NormalizedUserName" character varying(256),"Email" character varying(256),"NormalizedEmail" character varying(256),"EmailConfirmed" boolean NOT NULL DEFAULT false,"PasswordHash" text,"SecurityStamp" text,"ConcurrencyStamp" text,"PhoneNumber" text,"PhoneNumberConfirmed" boolean NOT NULL DEFAULT false,"TwoFactorEnabled" boolean NOT NULL DEFAULT false,"LockoutEnd" timestamptz,"LockoutEnabled" boolean NOT NULL DEFAULT false,"AccessFailedCount" integer NOT NULL DEFAULT 0);
        CREATE UNIQUE INDEX IF NOT EXISTS "UserNameIndex" ON "AspNetUsers"("NormalizedUserName") WHERE "NormalizedUserName" IS NOT NULL;
        CREATE INDEX IF NOT EXISTS "EmailIndex" ON "AspNetUsers"("NormalizedEmail") WHERE "NormalizedEmail" IS NOT NULL;
        CREATE TABLE IF NOT EXISTS "AspNetUserClaims"("Id" serial PRIMARY KEY,"UserId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE,"ClaimType" text,"ClaimValue" text);
        CREATE INDEX IF NOT EXISTS "IX_AspNetUserClaims_UserId" ON "AspNetUserClaims"("UserId");
        CREATE TABLE IF NOT EXISTS "AspNetUserLogins"("LoginProvider" text NOT NULL,"ProviderKey" text NOT NULL,"ProviderDisplayName" text,"UserId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE,PRIMARY KEY("LoginProvider","ProviderKey"));
        CREATE INDEX IF NOT EXISTS "IX_AspNetUserLogins_UserId" ON "AspNetUserLogins"("UserId");
        CREATE TABLE IF NOT EXISTS "AspNetUserTokens"("UserId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE,"LoginProvider" text NOT NULL,"Name" text NOT NULL,"Value" text,PRIMARY KEY("UserId","LoginProvider","Name"));
        CREATE TABLE IF NOT EXISTS "AspNetRoleClaims"("Id" serial PRIMARY KEY,"RoleId" text NOT NULL REFERENCES "AspNetRoles"("Id") ON DELETE CASCADE,"ClaimType" text,"ClaimValue" text);
        CREATE INDEX IF NOT EXISTS "IX_AspNetRoleClaims_RoleId" ON "AspNetRoleClaims"("RoleId");
        CREATE TABLE IF NOT EXISTS "AspNetUserRoles"("UserId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE,"RoleId" text NOT NULL REFERENCES "AspNetRoles"("Id") ON DELETE CASCADE,PRIMARY KEY("UserId","RoleId"));
        CREATE INDEX IF NOT EXISTS "IX_AspNetUserRoles_RoleId" ON "AspNetUserRoles"("RoleId");
        CREATE TABLE IF NOT EXISTS "ServiceTypes"("Id" serial PRIMARY KEY,"Name" text NOT NULL,"Description" text,"BasePrice" numeric(18,2) NOT NULL DEFAULT 0,"EstimatedHours" numeric(5,2) NOT NULL DEFAULT 1,"IsActive" boolean NOT NULL DEFAULT true);
        CREATE TABLE IF NOT EXISTS "Lifts"("Id" serial PRIMARY KEY,"Name" text NOT NULL,"Description" text,"IsActive" boolean NOT NULL DEFAULT true);
        CREATE TABLE IF NOT EXISTS "Parts"("Id" serial PRIMARY KEY,"Name" text NOT NULL,"ArticleNumber" text NOT NULL,"Description" text,"CompatibleBrands" text,"CategoryName" text,"PurchasePrice" numeric(18,2) NOT NULL DEFAULT 0,"SalePrice" numeric(18,2) NOT NULL DEFAULT 0,"StockQuantity" integer NOT NULL DEFAULT 0,"MinStockQuantity" integer NOT NULL DEFAULT 0,"IsActive" boolean NOT NULL DEFAULT true);
        CREATE TABLE IF NOT EXISTS "SystemSettings"("Id" serial PRIMARY KEY,"Key" text NOT NULL,"Value" text NOT NULL,"Description" text);
        CREATE UNIQUE INDEX IF NOT EXISTS "IX_SystemSettings_Key" ON "SystemSettings"("Key");
        CREATE TABLE IF NOT EXISTS "Cars"("Id" serial PRIMARY KEY,"OwnerId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE RESTRICT,"LicensePlate" text NOT NULL,"Brand" text NOT NULL,"Model" text NOT NULL,"Year" integer NOT NULL,"Vin" text,"Color" text,"IsDeleted" boolean NOT NULL DEFAULT false);
        CREATE INDEX IF NOT EXISTS "IX_Cars_OwnerId" ON "Cars"("OwnerId");
        CREATE TABLE IF NOT EXISTS "ServiceRequests"("Id" serial PRIMARY KEY,"ClientId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE RESTRICT,"CarId" integer NOT NULL REFERENCES "Cars"("Id") ON DELETE RESTRICT,"ServiceTypeId" integer REFERENCES "ServiceTypes"("Id"),"Status" integer NOT NULL DEFAULT 0,"Description" text NOT NULL DEFAULT '',"DiagnosticResult" text,"ManagerComment" text,"CancellationReason" text,"CreatedAt" timestamptz NOT NULL DEFAULT now(),"DesiredDate" timestamptz,"StartedAt" timestamptz,"CompletedAt" timestamptz,"Priority" integer NOT NULL DEFAULT 0);
        CREATE INDEX IF NOT EXISTS "IX_SR_ClientId" ON "ServiceRequests"("ClientId");
        CREATE INDEX IF NOT EXISTS "IX_SR_CarId" ON "ServiceRequests"("CarId");
        CREATE TABLE IF NOT EXISTS "MechanicAssignments"("Id" serial PRIMARY KEY,"ServiceRequestId" integer NOT NULL REFERENCES "ServiceRequests"("Id") ON DELETE CASCADE,"MechanicId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE RESTRICT,"LiftId" integer REFERENCES "Lifts"("Id"),"ScheduledStart" timestamptz,"ScheduledEnd" timestamptz,"WorkNotes" text);
        CREATE INDEX IF NOT EXISTS "IX_MA_ServiceRequestId" ON "MechanicAssignments"("ServiceRequestId");
        CREATE TABLE IF NOT EXISTS "UsedParts"("Id" serial PRIMARY KEY,"ServiceRequestId" integer NOT NULL REFERENCES "ServiceRequests"("Id") ON DELETE CASCADE,"PartId" integer NOT NULL REFERENCES "Parts"("Id") ON DELETE RESTRICT,"Quantity" integer NOT NULL DEFAULT 1,"PriceAtTime" numeric(18,2) NOT NULL DEFAULT 0);
        CREATE INDEX IF NOT EXISTS "IX_UP_ServiceRequestId" ON "UsedParts"("ServiceRequestId");
        CREATE TABLE IF NOT EXISTS "PartMovements"("Id" serial PRIMARY KEY,"PartId" integer NOT NULL REFERENCES "Parts"("Id") ON DELETE CASCADE,"MovementType" integer NOT NULL DEFAULT 0,"Quantity" integer NOT NULL DEFAULT 0,"Comment" text,"UserId" text,"CreatedAt" timestamptz NOT NULL DEFAULT now());
        CREATE TABLE IF NOT EXISTS "Invoices"("Id" serial PRIMARY KEY,"ServiceRequestId" integer NOT NULL UNIQUE REFERENCES "ServiceRequests"("Id") ON DELETE CASCADE,"LaborCost" numeric(18,2) NOT NULL DEFAULT 0,"PartsCost" numeric(18,2) NOT NULL DEFAULT 0,"Discount" numeric(18,2) NOT NULL DEFAULT 0,"PaymentStatus" integer NOT NULL DEFAULT 0,"PaidAmount" numeric(18,2) NOT NULL DEFAULT 0,"CreatedAt" timestamptz NOT NULL DEFAULT now(),"PaidAt" timestamptz,"Notes" text);
        CREATE TABLE IF NOT EXISTS "Reviews"("Id" serial PRIMARY KEY,"ServiceRequestId" integer NOT NULL UNIQUE REFERENCES "ServiceRequests"("Id") ON DELETE CASCADE,"ClientId" text NOT NULL REFERENCES "AspNetUsers"("Id") ON DELETE RESTRICT,"Rating" integer NOT NULL DEFAULT 5,"Comment" text,"CreatedAt" timestamptz NOT NULL DEFAULT now());
        CREATE INDEX IF NOT EXISTS "IX_Reviews_ClientId" ON "Reviews"("ClientId");
        CREATE TABLE IF NOT EXISTS "StatusHistories"("Id" serial PRIMARY KEY,"ServiceRequestId" integer NOT NULL REFERENCES "ServiceRequests"("Id") ON DELETE CASCADE,"OldStatus" integer NOT NULL DEFAULT 0,"NewStatus" integer NOT NULL DEFAULT 0,"Comment" text,"ChangedByUserId" text,"ChangedAt" timestamptz NOT NULL DEFAULT now());
        CREATE INDEX IF NOT EXISTS "IX_SH_ServiceRequestId" ON "StatusHistories"("ServiceRequestId");
        CREATE TABLE IF NOT EXISTS "__EFMigrationsHistory"("MigrationId" character varying(150) NOT NULL PRIMARY KEY,"ProductVersion" character varying(32) NOT NULL);
        """;
}
